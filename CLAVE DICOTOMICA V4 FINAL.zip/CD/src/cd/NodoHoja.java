/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cd;

import org.json.JSONArray;
/**
 * La clase NodoHoja representa un nodo en un árbol de decisiones que corresponde
 * a una hoja, es decir, un resultado final que contiene información sobre una especie.
 * Este nodo almacena el nombre de la especie y sus características asociadas.
 * 
 * @author edusye
 */
public class NodoHoja extends Nodo {
    private String especie;
    private JSONArray caracteristicas;
    
    /**
     * Constructor para crear un nuevo nodo hoja.
     *
     * @param id             El identificador único del nodo, heredado de la clase {@link Nodo}.
     * @param especie        El nombre de la especie identificada por este nodo hoja.
     * @param caracteristicas Un objeto {@link org.json.JSONArray} que contiene las
     * características de la especie.
     */
    public NodoHoja(String id, String especie, JSONArray caracteristicas) {
        super(id);
        this.especie = especie;
        this.caracteristicas = caracteristicas;
    }
    
     /**
     * Obtiene el nombre de la especie asociada a este nodo hoja.
     *
     * @return El nombre de la especie.
     */
    public String getEspecie() {
        return especie;
    }
    
    /**
     * Obtiene las características de la especie en formato {@link org.json.JSONArray}.
     *
     * @return Un {@link org.json.JSONArray} que contiene las características de la especie.
     */
    public JSONArray getCaracteristicas() {
        return caracteristicas;
    }
}