/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cd;

/**
 * La clase Nodo representa un nodo en un árbol de decisiones.
 * Cada nodo tiene un identificador único que lo distingue de otros nodos.
 * 
 * @author edusye
 */
public class Nodo {
    private String id; // Identificador único del nodo
    
    /**
     * Constructor para crear un nuevo nodo.
     *
     * @param id El identificador único que se asignará al nodo.
     */
    public Nodo(String id) {
        this.id = id;
    }
    
    /**
     * Obtiene el identificador único del nodo.
     *
     * @return El identificador del nodo.
     */
    public String getId() {
        return id;
    }
}