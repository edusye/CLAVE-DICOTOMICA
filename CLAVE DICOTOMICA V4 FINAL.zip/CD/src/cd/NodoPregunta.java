/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cd;

/**
 * La clase NodoPregunta representa un nodo en un árbol de decisiones que contiene
 * una pregunta y dos posibles respuestas (sí o no). Cada nodo de este tipo puede
 * tener un nodo hijo para la respuesta afirmativa y otro para la negativa.
 * 
 * @author edusye
 */
public class NodoPregunta extends Nodo {
    private String pregunta;
    private Nodo nodoSi;
    private Nodo nodoNo;
    
    /**
     * Constructor para crear un nuevo nodo de pregunta.
     *
     * @param id       El identificador único del nodo, heredado de la clase {@link Nodo}.
     * @param pregunta La pregunta asociada a este nodo.
     */
    public NodoPregunta(String id, String pregunta) {
        super(id); // Llama al constructor de Nodo
        this.pregunta = pregunta;
    }
    
    /**
     * Obtiene la pregunta almacenada en este nodo.
     *
     * @return La pregunta del nodo.
     */
    public String getPregunta() {
        return pregunta;
    }
    
    /**
     * Obtiene el nodo hijo que se sigue si la respuesta a la pregunta es "Sí".
     *
     * @return El nodo hijo para la respuesta afirmativa.
     */
    public Nodo getNodoSi() {
        return nodoSi;
    }
    
    /**
    * Establece el nodo hijo que se seguirá si la respuesta a la pregunta es "Sí".
    *
    * @param nodoSi El nodo hijo para la respuesta afirmativa.
    */
    public void setNodoSi(Nodo nodoSi) {
        this.nodoSi = nodoSi;
    }
    
    /**
     * Obtiene el nodo hijo que se sigue si la respuesta a la pregunta es "No".
     *
     * @return El nodo hijo para la respuesta negativa.
     */
    public Nodo getNodoNo() {
        return nodoNo;
    }
    
    /**
     * Establece el nodo hijo que se seguirá si la respuesta a la pregunta es "No".
     *
     * @param nodoNo El nodo hijo para la respuesta negativa.
     */
    public void setNodoNo(Nodo nodoNo) {
        this.nodoNo = nodoNo;
    }
}

