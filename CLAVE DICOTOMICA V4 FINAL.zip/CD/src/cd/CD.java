/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cd;

import GUI.Ventana1;

/**
 * Clase principal de la aplicación Clave Dicotomica (CD).
 * Esta clase contiene el método {@code main} que inicia la interfaz gráfica
 * de usuario, presentando la ventana principal de la aplicación {@link GUI.Ventana1}.
 * 
 * La aplicación permite a los usuarios identificar especies de plantas
 * a través de un árbol de decisiones basado en características.
 * 
 * @author edusye
 * @see GUI.Ventana1
 */
public class CD {

    /**
     * Método principal que se ejecuta al iniciar la aplicación.
     * Crea una instancia de la ventana principal {@link GUI.Ventana1},
     * la centra en la pantalla y la hace visible para el usuario.
     *
     * @param args Los argumentos de la línea de comandos (no se utilizan en esta aplicación).
     */
    public static void main(String[] args) {
        Ventana1 v1 = new Ventana1();
        v1.setLocationRelativeTo(null);
        v1.setVisible(true);
    }
    
}
