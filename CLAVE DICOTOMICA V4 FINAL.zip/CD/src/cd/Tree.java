/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cd;

import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.SingleGraph;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JPanel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import cd.Nodo;
import cd.NodoHoja;
import cd.NodoPregunta;
import java.awt.BorderLayout;
import java.awt.Component;
import java.util.Map;
import org.graphstream.ui.swing_viewer.SwingViewer;
import org.graphstream.ui.view.View;
import org.graphstream.ui.view.Viewer;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * La clase Tree representa un árbol de decisiones que se construye a partir de un
 * objeto JSON. Este árbol permite determinar la especie de una planta a partir
 * de preguntas y respuestas. También proporciona métodos para buscar especies
 * y visualizar el árbol gráficamente.
 * 
 * @author edusye
 */
public class Tree {
    private Nodo raiz;
    private Set<String> nodosAgregados = new HashSet<>();
    private Map<String, NodoHoja> especiesPorNombre; // Tabla hash
    
    /**
     * Constructor de la clase Tree. Recibe un objeto JSONObject que contiene
     * los datos para construir el árbol de decisión. Inicializa la tabla hash
     * de especies y construye el árbol a partir de los datos JSON.
     *
     * @param dataJSON El objeto JSONObject raíz que contiene la información del árbol.
     */
     public Tree(JSONObject dataJSON) { 
        this.especiesPorNombre = new HashMap<>();
        this.raiz = construirArbol(dataJSON); 
        popularTablaHash(raiz);
    }
    
    /**
     * Obtiene la raíz del árbol de decisión.
     *
     * @return El nodo raíz del árbol.
     */
    public Nodo getRaiz() {
        return raiz;
    }
    
    /**
     * Construye el árbol de decisión a partir de un objeto JSONObject.
     * Espera encontrar un JSONArray bajo la clave "Arboles templados", donde
     * cada elemento representa una especie con sus características.
     *
     * @param dataJSON El objeto JSONObject raíz que contiene los datos del árbol.
     * @return El nodo raíz del árbol construido, o null si hay un error o no hay datos.
     */
    private Nodo construirArbol(JSONObject dataJSON) {
        System.out.println("----------------------------------");
        System.out.println("Construir árbol:");

        if (!dataJSON.has("Arboles templados")) {
            System.out.println("Error: No se encontró la clave 'Arboles templados' en el JSON.");
            return null;
        }

        JSONArray arbolesTempladosArray = dataJSON.getJSONArray("Arboles templados");

        System.out.println("Construir árbol con " + arbolesTempladosArray.length() + " especies:");
        JSONArray especiesParaArbol = new JSONArray(); // Array para construir el árbol

        for (int i = 0; i < arbolesTempladosArray.length(); i++) {
            JSONObject especieWrapper = arbolesTempladosArray.getJSONObject(i);
            String nombreEspecie = especieWrapper.keySet().iterator().next();
            System.out.println("  - " + nombreEspecie);
            JSONArray caracteristicasArray = (JSONArray) especieWrapper.get(nombreEspecie);

            JSONObject especieConCaracteristicas = new JSONObject();
            especieConCaracteristicas.put(nombreEspecie, caracteristicasArray);
            especiesParaArbol.put(especieConCaracteristicas);
        }

        if (especiesParaArbol.isEmpty()) {
            return null;
        }

        return construirArbolRecursivoDesdeLista(especiesParaArbol);
    }
    
    /**
     * Construye recursivamente los nodos del árbol de decisión a partir de una
     * lista de especies en formato JSONArray. Intenta encontrar una característica
     * que pueda dividir el conjunto de especies actual. Si solo queda una especie,
     * crea un nodo hoja. Si no se encuentra una característica divisoria, crea un
     * nodo hoja con las posibles especies.
     *
     * @param especiesJSON JSONArray de objetos JSON, donde cada objeto representa una especie
     * con sus características.
     * @return El nodo construido a partir de la lista de especies.
     */
    private Nodo construirArbolRecursivoDesdeLista(JSONArray especiesJSON) {
        System.out.println("----------------------------------");
        System.out.println("Construir nodo con " + especiesJSON.length() + " especies:");
        for (int i = 0; i < especiesJSON.length(); i++) {
            JSONObject especieObj = especiesJSON.getJSONObject(i);
            System.out.println("  - " + especieObj.keySet().iterator().next());
        }
        System.out.println("----------------------------------");

        if (especiesJSON.length() == 1) {
            JSONObject especieObj = especiesJSON.getJSONObject(0);
            String nombreEspecie = especieObj.keySet().iterator().next();
            JSONArray caracteristicasArray = (JSONArray) especieObj.get(nombreEspecie);
            NodoHoja hoja = new NodoHoja(nombreEspecie, nombreEspecie, caracteristicasArray);
            System.out.println("Creando nodo hoja: " + nombreEspecie);
            return hoja;
        }

        if (especiesJSON.isEmpty()) {
            System.out.println("No hay especies para construir el nodo.");
            return null;
        }

        String primeraCaracteristica = null;

        for (int i = 0; i < especiesJSON.length(); i++) {
            JSONObject especieObj = especiesJSON.getJSONObject(i);
            String nombreEspecie = especieObj.keySet().iterator().next();
            JSONArray caracteristicasArray = (JSONArray) especieObj.get(nombreEspecie);
            for (int j = 0; j < caracteristicasArray.length(); j++) {
                JSONObject caracteristicaObj = caracteristicasArray.getJSONObject(j);
                String unaCaracteristica = caracteristicaObj.keySet().iterator().next();
                if (puedeDividir(especiesJSON, unaCaracteristica)) {
                    primeraCaracteristica = unaCaracteristica;
                    break;
                }
            }
            if (primeraCaracteristica != null) {
                break;
            }
        }

        if (primeraCaracteristica == null) {
            StringBuilder especies = new StringBuilder();
            for (int i = 0; i < especiesJSON.length(); i++) {
                JSONObject especieObj = especiesJSON.getJSONObject(i);
                especies.append(especieObj.keySet().iterator().next());
                if (i < especiesJSON.length() - 1) {
                    especies.append(", ");
                }
            }
            NodoHoja hoja = new NodoHoja("Posiblemente: " + especies.toString(), "Posiblemente: " + especies.toString(), new JSONArray());
            return hoja;
        }

        JSONArray siEspecies = new JSONArray();
        JSONArray noEspecies = new JSONArray();

        for (int i = 0; i < especiesJSON.length(); i++) {
            JSONObject especieObj = especiesJSON.getJSONObject(i);
            String nombreEspecie = especieObj.keySet().iterator().next();
            JSONArray caracteristicasArray = (JSONArray) especieObj.get(nombreEspecie);
            boolean tieneCaracteristica = false;
            boolean valorCaracteristica = false;

            for (int j = 0; j < caracteristicasArray.length(); j++) {
                JSONObject caracteristicaObj = caracteristicasArray.getJSONObject(j);
                if (caracteristicaObj.has(primeraCaracteristica)) {
                    tieneCaracteristica = true;
                    valorCaracteristica = caracteristicaObj.getBoolean(primeraCaracteristica);
                    break;
                }
            }

            JSONObject nuevaEspecieObj = new JSONObject();
            nuevaEspecieObj.put(nombreEspecie, caracteristicasArray);

            if (tieneCaracteristica) {
                if (valorCaracteristica) {
                    siEspecies.put(nuevaEspecieObj);
                } else {
                    noEspecies.put(nuevaEspecieObj);
                }
            } else {
                noEspecies.put(nuevaEspecieObj);
            }
        }

        NodoPregunta nodoPregunta = new NodoPregunta("¿" + primeraCaracteristica + "?", "¿" + primeraCaracteristica + "?");
        nodoPregunta.setNodoSi(construirArbolRecursivoDesdeLista(siEspecies));
        nodoPregunta.setNodoNo(construirArbolRecursivoDesdeLista(noEspecies));

        return nodoPregunta;
    }
    
    /**
    * Popula la tabla hash {@code especiesPorNombre} con todas las especies
    * encontradas en los nodos hoja del árbol de decisión.
    *
    * @param nodo El nodo actual a partir del cual se realiza la búsqueda recursiva.
    */
    private void popularTablaHash(Nodo nodo) {
        if (nodo instanceof NodoHoja nodoHoja) {
            especiesPorNombre.put(nodoHoja.getEspecie().toLowerCase(), nodoHoja);
        } else if (nodo instanceof NodoPregunta nodoPregunta) {
            popularTablaHash(nodoPregunta.getNodoSi());
            popularTablaHash(nodoPregunta.getNodoNo());
        }
    }

    /**
     * Construye un subárbol recursivamente a partir de un objeto JSONObject que
     * describe un nodo (pregunta o especie). Este método asume que el JSON tiene
     * una estructura específica con campos como "tipo", "id", "pregunta", "si", "no", "nombre", "caracteristicas".
     *
     * @param nodoJSON El objeto JSONObject que describe el nodo a construir.
     * @return El nodo ({@link NodoPregunta} o {@link NodoHoja}) construido a partir del JSON.
     */
    private Nodo construirNodoRecursivo(JSONObject nodoJSON) {
        String tipo = nodoJSON.getString("tipo");
        String id = nodoJSON.getString("id"); 

        if (tipo.equals("pregunta")) {
            String pregunta = nodoJSON.getString("pregunta");
            JSONObject siJSON = nodoJSON.getJSONObject("si");
            JSONObject noJSON = nodoJSON.getJSONObject("no");
            NodoPregunta nodo = new NodoPregunta(id, pregunta); // Pasar id y pregunta
            nodo.setNodoSi(construirNodoRecursivo(siJSON));
            nodo.setNodoNo(construirNodoRecursivo(noJSON));
            return nodo;
        } else if (tipo.equals("especie")) {
            String especie = nodoJSON.getString("nombre");
            JSONArray caracteristicasArray = nodoJSON.getJSONArray("caracteristicas"); 
            return new NodoHoja(id, especie, caracteristicasArray); // Pasar id, especie y características
        }
        return null; // Manejar otros casos si es necesario
    }

    /**
     * Busca una especie por su nombre utilizando la tabla hash {@code especiesPorNombre}.
     * Este método ofrece una búsqueda rápida con un tiempo de búsqueda constante en promedio.
     *
     * @param nombre El nombre de la especie a buscar.
     * @return Un objeto {@link ResultadoBusqueda} que contiene la especie encontrada (si existe),
     * un mensaje de error (si no se encuentra) y el tiempo de búsqueda en nanosegundos.
     */
    public ResultadoBusqueda buscarPorHash(String nombre) {
        long startTime = System.nanoTime();
        NodoHoja especie = especiesPorNombre.get(nombre.toLowerCase());
        long endTime = System.nanoTime();
        long duration = endTime - startTime;
        if (especie != null) {
            return new Tree.ResultadoBusqueda(especie.getEspecie(), especie.getCaracteristicas(), duration); // Pasar características
        } else {
            return new Tree.ResultadoBusqueda(null, "Especie no encontrada por hash.", duration);
        }
    }

     /**
     * Busca una especie por su nombre recorriendo el árbol de decisión desde la raíz.
     * Este método sigue las ramas del árbol basándose en el nombre de la especie
     * hasta encontrar un nodo hoja con el nombre coincidente.
     *
     * @param nombre El nombre de la especie a buscar.
     * @return Un objeto {@link ResultadoBusqueda} que contiene la especie encontrada (si existe),
     * las preguntas realizadas durante el recorrido, un mensaje de error (si no se encuentra)
     * y el tiempo de búsqueda en nanosegundos.
     */
    public ResultadoBusqueda buscarPorRecorrido(String nombre) {
         long startTime = System.nanoTime();
        List<String> preguntas = new ArrayList<>();
        NodoHoja especieEncontrada = buscarRecursivo(raiz, nombre, preguntas);
        long endTime = System.nanoTime();
        long duration = endTime - startTime;
        if (especieEncontrada != null) {
            JSONArray preguntasJSONArray = new JSONArray(preguntas);
            return new ResultadoBusqueda(especieEncontrada.getEspecie(), null, duration, preguntasJSONArray); // Pasar null para caracteristicasHash
        } else {
            return new ResultadoBusqueda(null, "Especie no encontrada por recorrido.", duration);
        }
    }
    
    /**
     * Realiza la búsqueda recursiva de una especie en el árbol de decisión.
     *
     * @param nodo      El nodo actual que se está visitando.
     * @param nombre    El nombre de la especie a buscar.
     * @param preguntas Lista para almacenar las preguntas encontradas en el camino.
     * @return El {@link NodoHoja} si la especie es encontrada, o null si no.
     */
    private NodoHoja buscarRecursivo(Nodo nodo, String nombre, List<String> preguntas) {

        if (nodo instanceof NodoHoja nodoHoja) {
            if (nodoHoja.getEspecie().toLowerCase().equals(nombre.toLowerCase())) {
                return nodoHoja;
            }
            return null;
        } else if (nodo instanceof NodoPregunta nodoPregunta) {
            String preguntaCompleta = nodoPregunta.getPregunta();
            String preguntaTexto = "";
            if (preguntaCompleta.length() > 2) {
                preguntaTexto = preguntaCompleta.substring(1, preguntaCompleta.length() - 1);
            } else {
                preguntaTexto = preguntaCompleta; 
            }
            preguntas.add(preguntaTexto);

            NodoHoja resultadoSi = buscarRecursivo(nodoPregunta.getNodoSi(), nombre, preguntas);
            if (resultadoSi != null) {
                return resultadoSi;
            }

 
            if (!preguntas.isEmpty()) {
                preguntas.remove(preguntas.size() - 1);
            }


            NodoHoja resultadoNo = buscarRecursivo(nodoPregunta.getNodoNo(), nombre, preguntas);
            if (resultadoNo != null) {
                return resultadoNo;
            }
        }
        return null;
    }
    
    /**
     * Clase interna para representar el resultado de una búsqueda de especie.
     * Contiene la especie encontrada, las preguntas realizadas (para la búsqueda por recorrido),
     * el tiempo de búsqueda, un mensaje de error (si la búsqueda falla) y las características
     * de la especie (para la búsqueda por hash).
     */
    public static class ResultadoBusqueda {
        private String especie;
        private JSONArray preguntas;
        private long tiempoNano;
        private String mensajeError;
        private JSONArray caracteristicasHash;

    public ResultadoBusqueda(String especie, JSONArray caracteristicasHash, long tiempoNano, JSONArray preguntas) {
        this.especie = especie;
        this.preguntas = preguntas;
        this.tiempoNano = tiempoNano;
        this.mensajeError = null;
        this.caracteristicasHash = caracteristicasHash;
    }

    public ResultadoBusqueda(String especie, String mensajeError, long tiempoNano) {
        this(especie, null, tiempoNano, null); // Llama al constructor principal con preguntas null
        this.mensajeError = mensajeError;
    }

    public ResultadoBusqueda(String especie, JSONArray caracteristicasHash, long tiempoNano) {
        this(especie, caracteristicasHash, tiempoNano, null); // Llama al constructor principal con preguntas null
    }
    
    /**
         * Obtiene la especie encontrada.
         *
         * @return El nombre de la especie, o null si no se encontró.
         */
    public String getEspecie() {
            return especie;
        }
    
    /**
    * Obtiene las preguntas realizadas durante la búsqueda por recorrido.
    *
    * @return Un JSONArray de cadenas con las preguntas, o null si no se realizó por recorrido.
    */
    public JSONArray getPreguntas() {
            return preguntas;
        }

    
    public long getTiempoNano() {
            return tiempoNano;
        }
    
    /**
     * Obtiene el mensaje de error en caso de que la búsqueda no haya sido exitosa.
     *
     * @return Una cadena con el mensaje de error, o null si no hubo error.
     */
    public String getMensajeError() {
            return mensajeError;
        }
    
    /**
     * Obtiene las características de la especie encontradas mediante la búsqueda por hash.
     *
     * @return Un JSONArray con las características de la especie, o null si no se usó hash.
     */
    public JSONArray getCaracteristicasHash() {
            return caracteristicasHash;
        }
    }

    /**
    * Determina si una característica dada puede dividir el conjunto actual de especies.
    * Una característica puede dividir el conjunto si al menos una especie en el conjunto
    * tiene la característica con valor verdadero y al menos otra especie la tiene con valor falso.
    *
    * @param especiesJSON    JSONArray de objetos JSON, donde cada objeto representa una especie
    * con sus características.
    * @param caracteristica La característica que se va a evaluar para la división.
    * @return true si la característica puede dividir el conjunto de especies, false en caso contrario.
    */
    private boolean puedeDividir(JSONArray especiesJSON, String caracteristica) {
        boolean tieneVerdadero = false;
        boolean tieneFalso = false;

        for (int i = 0; i < especiesJSON.length(); i++) {
            JSONObject especieObj = especiesJSON.getJSONObject(i);
            String nombreEspecie = especieObj.keySet().iterator().next();
            JSONArray caracteristicasArray = (JSONArray) especieObj.get(nombreEspecie);

            for (int j = 0; j < caracteristicasArray.length(); j++) {
                JSONObject caracteristicaObj = caracteristicasArray.getJSONObject(j);
                if (caracteristicaObj.has(caracteristica)) {
                    if (caracteristicaObj.getBoolean(caracteristica)) {
                        tieneVerdadero = true;
                    } else {
                        tieneFalso = true;
                    }
                    break;
                }
            }
        }
        System.out.println("Característica: " + caracteristica + ", tieneVerdadero: " + tieneVerdadero + ", tieneFalso: " + tieneFalso);
        return tieneVerdadero && tieneFalso;
    }
    
    /**
    * Intenta determinar la especie de árbol basándose en un mapa de respuestas
    * a las preguntas del árbol de decisión. Recorre el árbol según las respuestas proporcionadas.
    *
    * @param respuestas Un mapa donde las claves son las preguntas (sin los caracteres "¿?" al principio y al final)
    * y los valores son las respuestas (Boolean.TRUE para "Sí", Boolean.FALSE para "No").
    * @return El nombre de la especie determinada si se llega a un nodo hoja, o un mensaje
    * indicando que falta una respuesta o que no se pudo determinar la especie.
    */
    public String determineSpecies(Map<String, Boolean> respuestas) {
        Nodo actual = raiz;
        while (actual instanceof NodoPregunta) {
            NodoPregunta nodoPregunta = (NodoPregunta) actual;
            String pregunta = nodoPregunta.getPregunta().substring(1, nodoPregunta.getPregunta().length() - 1);
            if (respuestas.containsKey(pregunta)) {
                if (respuestas.get(pregunta)) {
                    actual = nodoPregunta.getNodoSi();
                } else {
                    actual = nodoPregunta.getNodoNo();
                }
            } else {
                return "Respuesta faltante para la pregunta: " + nodoPregunta.getPregunta();
            }
        }
        if (actual instanceof NodoHoja nodoHoja) {
            return nodoHoja.getEspecie();
        }
        return "No se pudo determinar la especie.";
    }
    
    /**
    * Imprime el árbol de decisión en la consola, mostrando la estructura de preguntas y resultados.
    */
    public void imprimirArbol() {
        imprimirNodo(raiz, 0);
    }
    
    /**
    * Método auxiliar recursivo para imprimir un nodo del árbol y sus hijos con una indentación según el nivel.
    *
    * @param nodo  El nodo actual a imprimir.
    * @param nivel El nivel de indentación.
    */
    private void imprimirNodo(Nodo nodo, int nivel) {
        if (nodo == null) {
            return;
        }

        for (int i = 0; i < nivel; i++) {
            System.out.print("  ");
        }

        switch (nodo) {
            case NodoPregunta preguntaNodo -> {
                System.out.println("¿" + preguntaNodo.getPregunta().substring(1, preguntaNodo.getPregunta().length() - 1) + "?");
                imprimirNodo(preguntaNodo.getNodoSi(), nivel + 1);
                imprimirNodo(preguntaNodo.getNodoNo(), nivel + 1);
            }
            case NodoHoja hojaNodo -> System.out.println("Resultado: " + hojaNodo.getEspecie());
            default -> {
            }
        }
    }
    
    /**
    * Muestra el árbol de decisión gráficamente en un panel Swing utilizando la biblioteca GraphStream.
    *
    * @param panelContenedor El JPanel donde se renderizará el grafo del árbol.
    */
    public void mostrarArbolGraficamente(JPanel panelContenedor) {
        System.setProperty("org.graphstream.ui", "swing");

        Graph graph = new SingleGraph("Decision Tree");
        nodosAgregados.clear(); // Reiniciar el conjunto de nodos agregados

        agregarNodosYAristasAlGrafo(graph, raiz);

        graph.setAttribute("ui.stylesheet", styleSheet);

        SwingViewer viewer = new SwingViewer(graph, Viewer.ThreadingModel.GRAPH_IN_GUI_THREAD);
        viewer.enableAutoLayout();
        View view = viewer.addDefaultView(false);
        Component viewComponent = (Component) view;

        panelContenedor.removeAll();
        panelContenedor.setLayout(new BorderLayout());
        panelContenedor.add(viewComponent, BorderLayout.CENTER);
        panelContenedor.revalidate();
        panelContenedor.repaint();
    }
    
    /**
    * Agrega recursivamente los nodos y las aristas del árbol de decisión al grafo de GraphStream.
    * Utiliza el ID de cada nodo para evitar duplicados.
    *
    * @param graph El grafo de GraphStream al que se agregarán los elementos.
    * @param nodo  El nodo actual del árbol de decisión que se está procesando.
    */
    private void agregarNodosYAristasAlGrafo(Graph graph, Nodo nodo) {
        if (nodo == null) {
            return;
        }

        // Usar el método getId() para obtener un identificador único
        String nodeId = nodo.getId();

        // Verificar si el nodo ya ha sido agregado
        if (!nodosAgregados.contains(nodeId)) {
            // Establecer la etiqueta del nodo
            graph.addNode(nodeId).setAttribute("ui.label", obtenerEtiquetaNodo(nodo));
            nodosAgregados.add(nodeId); // Agregar el nodo a la lista de nodos agregados
        }

        // Agregar las aristas al grafo
        if (nodo instanceof NodoPregunta preguntaNodo) {
            if (preguntaNodo.getNodoSi() != null) {
                String siNodeId = preguntaNodo.getNodoSi().getId();
                if (!nodosAgregados.contains(siNodeId)) {
                    graph.addNode(siNodeId).setAttribute("ui.label", obtenerEtiquetaNodo(preguntaNodo.getNodoSi()));
                    nodosAgregados.add(siNodeId);
                }
                // Establecer la etiqueta de la arista "Sí"
                graph.addEdge(nodeId + "-" + siNodeId, nodeId, siNodeId).setAttribute("ui.label", "Sí");
            }
            if (preguntaNodo.getNodoNo() != null) {
                String noNodeId = preguntaNodo.getNodoNo().getId();
                if (!nodosAgregados.contains(noNodeId)) {
                    graph.addNode(noNodeId).setAttribute("ui.label", obtenerEtiquetaNodo(preguntaNodo.getNodoNo()));
                    nodosAgregados.add(noNodeId);
                }
                // Establecer la etiqueta de la arista "No"
                graph.addEdge(nodeId + "-" + noNodeId, nodeId, noNodeId).setAttribute("ui.label", "No");
            }
        }

        // Recursividad para agregar los nodos hijos
        if (nodo instanceof NodoPregunta preguntaNodo) {
            agregarNodosYAristasAlGrafo(graph, preguntaNodo.getNodoSi());
            agregarNodosYAristasAlGrafo(graph, preguntaNodo.getNodoNo());
        }
    }
    
    /**
    * Obtiene la etiqueta que se mostrará en el grafo para un nodo dado.
    *
    * @param nodo El nodo del árbol de decisión.
    * @return La etiqueta del nodo como una cadena.
    */
    private String obtenerEtiquetaNodo(Nodo nodo) {
        switch (nodo) {
            case NodoPregunta nodoPregunta -> {
                return "¿" + nodoPregunta.getPregunta().substring(1, nodoPregunta.getPregunta().length() - 1) + "?";
            }
            case NodoHoja nodoHoja -> {
                return "Resultado: " + nodoHoja.getEspecie();
            }
            default -> {
            }
        }
        return "Nodo"; // Etiqueta por defecto si algo va mal
    }
    
    
    private static String styleSheet =
            "node {" +
                    "   fill-color: #eee;" +
                    "   stroke-mode: plain;" +
                    "   stroke-color: #222;" +
                    "   size: 20px;" +
                    "   text-alignment: center;" +
                    "   text-size: 12px;" +
                    "}" +
                    "node.pregunta {" +
                    "   fill-color: #ccf;" +
                    "}" +
                    "node.hoja {" +
                    "   fill-color: #cfc;" +
                    "}" +
                    "edge {" +
                    "   shape: line;" +
                    "   arrow-size: 8px, 4px;" +
                    "   text-size: 10px;" +
                    "}";
    }
