/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cd;

import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.SingleGraph;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JPanel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import cd.Nodo;
import cd.NodoHoja;
import cd.NodoPregunta;
import java.awt.BorderLayout;
import java.awt.Component;
import java.util.Map;
import org.graphstream.ui.swing_viewer.SwingViewer;
import org.graphstream.ui.view.View;
import org.graphstream.ui.view.Viewer;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author edusye
 */
public class Tree {
    private Nodo raiz;
    private Set<String> nodosAgregados = new HashSet<>();
    private Map<String, NodoHoja> especiesPorNombre; // Tabla hash
    

     public Tree(JSONObject dataJSON) { // Ahora recibe el JSONObject raíz
        this.especiesPorNombre = new HashMap<>();
        this.raiz = construirArbol(dataJSON); // Pasar el JSONObject raíz a construirArbol
        popularTablaHash(raiz);
    }
    
    public Nodo getRaiz() {
        return raiz;
    }

     private Nodo construirArbol(JSONObject dataJSON) {
        System.out.println("----------------------------------");
        System.out.println("Construir árbol:");

        if (!dataJSON.has("Arboles templados")) {
            System.out.println("Error: No se encontró la clave 'Arboles templados' en el JSON.");
            return null;
        }

        JSONArray arbolesTempladosArray = dataJSON.getJSONArray("Arboles templados");

        System.out.println("Construir árbol con " + arbolesTempladosArray.length() + " especies:");
        JSONArray especiesParaArbol = new JSONArray(); // Array para construir el árbol

        for (int i = 0; i < arbolesTempladosArray.length(); i++) {
            JSONObject especieWrapper = arbolesTempladosArray.getJSONObject(i);
            String nombreEspecie = especieWrapper.keySet().iterator().next();
            System.out.println("  - " + nombreEspecie);
            JSONArray caracteristicasArray = (JSONArray) especieWrapper.get(nombreEspecie);

            JSONObject especieConCaracteristicas = new JSONObject();
            especieConCaracteristicas.put(nombreEspecie, caracteristicasArray);
            especiesParaArbol.put(especieConCaracteristicas);
        }

        if (especiesParaArbol.isEmpty()) {
            return null;
        }

        // Ahora 'especiesParaArbol' tiene la estructura que tu método construirArbol esperaba
        return construirArbolRecursivoDesdeLista(especiesParaArbol);
    }

    private Nodo construirArbolRecursivoDesdeLista(JSONArray especiesJSON) {
        System.out.println("----------------------------------");
        System.out.println("Construir nodo con " + especiesJSON.length() + " especies:");
        for (int i = 0; i < especiesJSON.length(); i++) {
            JSONObject especieObj = especiesJSON.getJSONObject(i);
            System.out.println("  - " + especieObj.keySet().iterator().next());
        }
        System.out.println("----------------------------------");

        if (especiesJSON.length() == 1) {
            JSONObject especieObj = especiesJSON.getJSONObject(0);
            String nombreEspecie = especieObj.keySet().iterator().next();
            JSONArray caracteristicasArray = (JSONArray) especieObj.get(nombreEspecie);
            NodoHoja hoja = new NodoHoja(nombreEspecie, nombreEspecie, caracteristicasArray);
            System.out.println("Creando nodo hoja: " + nombreEspecie);
            return hoja;
        }

        if (especiesJSON.isEmpty()) {
            System.out.println("No hay especies para construir el nodo.");
            return null;
        }

        String primeraCaracteristica = null;

        // Buscar la primera característica que pueda dividir el conjunto actual
        for (int i = 0; i < especiesJSON.length(); i++) {
            JSONObject especieObj = especiesJSON.getJSONObject(i);
            String nombreEspecie = especieObj.keySet().iterator().next();
            JSONArray caracteristicasArray = (JSONArray) especieObj.get(nombreEspecie);
            for (int j = 0; j < caracteristicasArray.length(); j++) {
                JSONObject caracteristicaObj = caracteristicasArray.getJSONObject(j);
                String unaCaracteristica = caracteristicaObj.keySet().iterator().next();
                if (puedeDividir(especiesJSON, unaCaracteristica)) {
                    primeraCaracteristica = unaCaracteristica;
                    break;
                }
            }
            if (primeraCaracteristica != null) {
                break;
            }
        }

        if (primeraCaracteristica == null) {
            StringBuilder especies = new StringBuilder();
            for (int i = 0; i < especiesJSON.length(); i++) {
                JSONObject especieObj = especiesJSON.getJSONObject(i);
                especies.append(especieObj.keySet().iterator().next());
                if (i < especiesJSON.length() - 1) {
                    especies.append(", ");
                }
            }
            NodoHoja hoja = new NodoHoja("Posiblemente: " + especies.toString(), "Posiblemente: " + especies.toString(), new JSONArray());
            return hoja;
        }

        JSONArray siEspecies = new JSONArray();
        JSONArray noEspecies = new JSONArray();

        for (int i = 0; i < especiesJSON.length(); i++) {
            JSONObject especieObj = especiesJSON.getJSONObject(i);
            String nombreEspecie = especieObj.keySet().iterator().next();
            JSONArray caracteristicasArray = (JSONArray) especieObj.get(nombreEspecie);
            boolean tieneCaracteristica = false;
            boolean valorCaracteristica = false;

            for (int j = 0; j < caracteristicasArray.length(); j++) {
                JSONObject caracteristicaObj = caracteristicasArray.getJSONObject(j);
                if (caracteristicaObj.has(primeraCaracteristica)) {
                    tieneCaracteristica = true;
                    valorCaracteristica = caracteristicaObj.getBoolean(primeraCaracteristica);
                    break;
                }
            }

            JSONObject nuevaEspecieObj = new JSONObject();
            nuevaEspecieObj.put(nombreEspecie, caracteristicasArray);

            if (tieneCaracteristica) {
                if (valorCaracteristica) {
                    siEspecies.put(nuevaEspecieObj);
                } else {
                    noEspecies.put(nuevaEspecieObj);
                }
            } else {
                // Manejar el caso en que la especie no tiene la característica (podría ser un error en los datos
                noEspecies.put(nuevaEspecieObj);
            }
        }

        NodoPregunta nodoPregunta = new NodoPregunta("¿" + primeraCaracteristica + "?", "¿" + primeraCaracteristica + "?");
        nodoPregunta.setNodoSi(construirArbolRecursivoDesdeLista(siEspecies));
        nodoPregunta.setNodoNo(construirArbolRecursivoDesdeLista(noEspecies));

        return nodoPregunta;
    }

    private void popularTablaHash(Nodo nodo) {
        if (nodo instanceof NodoHoja nodoHoja) {
            especiesPorNombre.put(nodoHoja.getEspecie().toLowerCase(), nodoHoja);
        } else if (nodo instanceof NodoPregunta nodoPregunta) {
            popularTablaHash(nodoPregunta.getNodoSi());
            popularTablaHash(nodoPregunta.getNodoNo());
        }
    }
    
    private Nodo construirNodoRecursivo(JSONObject nodoJSON) {
        String tipo = nodoJSON.getString("tipo");
        String id = nodoJSON.getString("id"); // Asegúrate de que tu JSON tenga un campo "id"

        if (tipo.equals("pregunta")) {
            String pregunta = nodoJSON.getString("pregunta");
            JSONObject siJSON = nodoJSON.getJSONObject("si");
            JSONObject noJSON = nodoJSON.getJSONObject("no");
            NodoPregunta nodo = new NodoPregunta(id, pregunta); // Pasar id y pregunta
            nodo.setNodoSi(construirNodoRecursivo(siJSON));
            nodo.setNodoNo(construirNodoRecursivo(noJSON));
            return nodo;
        } else if (tipo.equals("especie")) {
            String especie = nodoJSON.getString("nombre");
            JSONArray caracteristicasArray = nodoJSON.getJSONArray("caracteristicas"); // Asegúrate de obtener las características
            return new NodoHoja(id, especie, caracteristicasArray); // Pasar id, especie y características
        }
        return null; // Manejar otros casos si es necesario
    }

    
    public ResultadoBusqueda buscarPorHash(String nombre) {
        long startTime = System.nanoTime();
        NodoHoja especie = especiesPorNombre.get(nombre.toLowerCase());
        long endTime = System.nanoTime();
        long duration = endTime - startTime;
        if (especie != null) {
            return new Tree.ResultadoBusqueda(especie.getEspecie(), especie.getCaracteristicas(), duration); // Pasar características
        } else {
            return new Tree.ResultadoBusqueda(null, "Especie no encontrada por hash.", duration);
        }
    }

    
    public ResultadoBusqueda buscarPorRecorrido(String nombre) {
         long startTime = System.nanoTime();
        List<String> preguntas = new ArrayList<>();
        NodoHoja especieEncontrada = buscarRecursivo(raiz, nombre, preguntas);
        long endTime = System.nanoTime();
        long duration = endTime - startTime;
        if (especieEncontrada != null) {
            JSONArray preguntasJSONArray = new JSONArray(preguntas);
            return new ResultadoBusqueda(especieEncontrada.getEspecie(), null, duration, preguntasJSONArray); // Pasar null para caracteristicasHash
        } else {
            return new ResultadoBusqueda(null, "Especie no encontrada por recorrido.", duration);
        }
    }
    private NodoHoja buscarRecursivo(Nodo nodo, String nombre, List<String> preguntas) {

        if (nodo instanceof NodoHoja nodoHoja) {
            if (nodoHoja.getEspecie().toLowerCase().equals(nombre.toLowerCase())) {
                return nodoHoja;
            }
            return null;
        } else if (nodo instanceof NodoPregunta nodoPregunta) {
            String preguntaCompleta = nodoPregunta.getPregunta();
            String preguntaTexto = "";
            if (preguntaCompleta.length() > 2) {
                preguntaTexto = preguntaCompleta.substring(1, preguntaCompleta.length() - 1);
            } else {
                preguntaTexto = preguntaCompleta; // O manejar el caso de pregunta corta de otra manera
            }
            preguntas.add(preguntaTexto);

            NodoHoja resultadoSi = buscarRecursivo(nodoPregunta.getNodoSi(), nombre, preguntas);
            if (resultadoSi != null) {
                return resultadoSi;
            }

 
            if (!preguntas.isEmpty()) {
                preguntas.remove(preguntas.size() - 1);
            }


            NodoHoja resultadoNo = buscarRecursivo(nodoPregunta.getNodoNo(), nombre, preguntas);
            if (resultadoNo != null) {
                return resultadoNo;
            }
        }
        return null;
    }

    public static class ResultadoBusqueda {
        private String especie;
        private JSONArray preguntas;
        private long tiempoNano;
        private String mensajeError;
        private JSONArray caracteristicasHash;

    public ResultadoBusqueda(String especie, JSONArray caracteristicasHash, long tiempoNano, JSONArray preguntas) {
        this.especie = especie;
        this.preguntas = preguntas;
        this.tiempoNano = tiempoNano;
        this.mensajeError = null;
        this.caracteristicasHash = caracteristicasHash;
    }

    public ResultadoBusqueda(String especie, String mensajeError, long tiempoNano) {
        this(especie, null, tiempoNano, null); // Llama al constructor principal con preguntas null
        this.mensajeError = mensajeError;
    }

    public ResultadoBusqueda(String especie, JSONArray caracteristicasHash, long tiempoNano) {
        this(especie, caracteristicasHash, tiempoNano, null); // Llama al constructor principal con preguntas null
    }

        public String getEspecie() {
            return especie;
        }

        public JSONArray getPreguntas() {
            return preguntas;
        }

        public long getTiempoNano() {
            return tiempoNano;
        }

        public String getMensajeError() {
            return mensajeError;
        }

        public JSONArray getCaracteristicasHash() {
            return caracteristicasHash;
        }
    }

    
    private boolean puedeDividir(JSONArray especiesJSON, String caracteristica) {
        boolean tieneVerdadero = false;
        boolean tieneFalso = false;

        for (int i = 0; i < especiesJSON.length(); i++) {
            JSONObject especieObj = especiesJSON.getJSONObject(i);
            String nombreEspecie = especieObj.keySet().iterator().next();
            JSONArray caracteristicasArray = (JSONArray) especieObj.get(nombreEspecie);

            for (int j = 0; j < caracteristicasArray.length(); j++) {
                JSONObject caracteristicaObj = caracteristicasArray.getJSONObject(j);
                if (caracteristicaObj.has(caracteristica)) {
                    if (caracteristicaObj.getBoolean(caracteristica)) {
                        tieneVerdadero = true;
                    } else {
                        tieneFalso = true;
                    }
                    break;
                }
            }
        }
        System.out.println("Característica: " + caracteristica + ", tieneVerdadero: " + tieneVerdadero + ", tieneFalso: " + tieneFalso);
        return tieneVerdadero && tieneFalso;
    }

    public String determineSpecies(Map<String, Boolean> respuestas) {
        Nodo actual = raiz;
        while (actual instanceof NodoPregunta) {
            NodoPregunta nodoPregunta = (NodoPregunta) actual;
            String pregunta = nodoPregunta.getPregunta().substring(1, nodoPregunta.getPregunta().length() - 1);
            if (respuestas.containsKey(pregunta)) {
                if (respuestas.get(pregunta)) {
                    actual = nodoPregunta.getNodoSi();
                } else {
                    actual = nodoPregunta.getNodoNo();
                }
            } else {
                return "Respuesta faltante para la pregunta: " + nodoPregunta.getPregunta();
            }
        }
        if (actual instanceof NodoHoja nodoHoja) {
            return nodoHoja.getEspecie();
        }
        return "No se pudo determinar la especie.";
    }

    public void imprimirArbol() {
        imprimirNodo(raiz, 0);
    }

    private void imprimirNodo(Nodo nodo, int nivel) {
        if (nodo == null) {
            return;
        }

        for (int i = 0; i < nivel; i++) {
            System.out.print("  ");
        }

        switch (nodo) {
            case NodoPregunta preguntaNodo -> {
                System.out.println("¿" + preguntaNodo.getPregunta().substring(1, preguntaNodo.getPregunta().length() - 1) + "?");
                imprimirNodo(preguntaNodo.getNodoSi(), nivel + 1);
                imprimirNodo(preguntaNodo.getNodoNo(), nivel + 1);
            }
            case NodoHoja hojaNodo -> System.out.println("Resultado: " + hojaNodo.getEspecie());
            default -> {
            }
        }
    }

    public void mostrarArbolGraficamente(JPanel panelContenedor) {
        System.setProperty("org.graphstream.ui", "swing");

        Graph graph = new SingleGraph("Decision Tree");
        nodosAgregados.clear(); // Reiniciar el conjunto de nodos agregados

        agregarNodosYAristasAlGrafo(graph, raiz);

        graph.setAttribute("ui.stylesheet", styleSheet);

        SwingViewer viewer = new SwingViewer(graph, Viewer.ThreadingModel.GRAPH_IN_GUI_THREAD);
        viewer.enableAutoLayout();
        View view = viewer.addDefaultView(false);
        Component viewComponent = (Component) view;

        panelContenedor.removeAll();
        panelContenedor.setLayout(new BorderLayout());
        panelContenedor.add(viewComponent, BorderLayout.CENTER);
        panelContenedor.revalidate();
        panelContenedor.repaint();
    }

    private void agregarNodosYAristasAlGrafo(Graph graph, Nodo nodo) {
        if (nodo == null) {
            return;
        }

        // Usar el método getId() para obtener un identificador único
        String nodeId = nodo.getId();

        // Verificar si el nodo ya ha sido agregado
        if (!nodosAgregados.contains(nodeId)) {
            // Establecer la etiqueta del nodo
            graph.addNode(nodeId).setAttribute("ui.label", obtenerEtiquetaNodo(nodo));
            nodosAgregados.add(nodeId); // Agregar el nodo a la lista de nodos agregados
        }

        // Agregar las aristas al grafo
        if (nodo instanceof NodoPregunta preguntaNodo) {
            if (preguntaNodo.getNodoSi() != null) {
                String siNodeId = preguntaNodo.getNodoSi().getId();
                if (!nodosAgregados.contains(siNodeId)) {
                    graph.addNode(siNodeId).setAttribute("ui.label", obtenerEtiquetaNodo(preguntaNodo.getNodoSi()));
                    nodosAgregados.add(siNodeId);
                }
                // Establecer la etiqueta de la arista "Sí"
                graph.addEdge(nodeId + "-" + siNodeId, nodeId, siNodeId).setAttribute("ui.label", "Sí");
            }
            if (preguntaNodo.getNodoNo() != null) {
                String noNodeId = preguntaNodo.getNodoNo().getId();
                if (!nodosAgregados.contains(noNodeId)) {
                    graph.addNode(noNodeId).setAttribute("ui.label", obtenerEtiquetaNodo(preguntaNodo.getNodoNo()));
                    nodosAgregados.add(noNodeId);
                }
                // Establecer la etiqueta de la arista "No"
                graph.addEdge(nodeId + "-" + noNodeId, nodeId, noNodeId).setAttribute("ui.label", "No");
            }
        }

        // Recursividad para agregar los nodos hijos
        if (nodo instanceof NodoPregunta preguntaNodo) {
            agregarNodosYAristasAlGrafo(graph, preguntaNodo.getNodoSi());
            agregarNodosYAristasAlGrafo(graph, preguntaNodo.getNodoNo());
        }
    }

    private String obtenerEtiquetaNodo(Nodo nodo) {
        switch (nodo) {
            case NodoPregunta nodoPregunta -> {
                return "¿" + nodoPregunta.getPregunta().substring(1, nodoPregunta.getPregunta().length() - 1) + "?";
            }
            case NodoHoja nodoHoja -> {
                return "Resultado: " + nodoHoja.getEspecie();
            }
            default -> {
            }
        }
        return "Nodo"; // Etiqueta por defecto si algo va mal
    }
    // El método construirGrafo ya no es necesario aquí, ya que agregarNodosYAristasAlGrafo hace su trabajo
    // private void construirGrafo(Graph graph, Nodo nodo) { ... }

    private static String styleSheet =
            "node {" +
                    "   fill-color: #eee;" +
                    "   stroke-mode: plain;" +
                    "   stroke-color: #222;" +
                    "   size: 20px;" +
                    "   text-alignment: center;" +
                    "   text-size: 12px;" +
                    "}" +
                    "node.pregunta {" +
                    "   fill-color: #ccf;" +
                    "}" +
                    "node.hoja {" +
                    "   fill-color: #cfc;" +
                    "}" +
                    "edge {" +
                    "   shape: line;" +
                    "   arrow-size: 8px, 4px;" +
                    "   text-size: 10px;" +
                    "}";
    }
