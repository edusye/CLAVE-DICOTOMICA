/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cd;

import org.json.JSONArray;
/**
 *
 * @author edusye
 */
public class NodoHoja extends Nodo {
    private String especie;
    private JSONArray caracteristicas;

    public NodoHoja(String id, String especie, JSONArray caracteristicas) {
        super(id);
        this.especie = especie;
        this.caracteristicas = caracteristicas;
    }

    public String getEspecie() {
        return especie;
    }

    public JSONArray getCaracteristicas() {
        return caracteristicas;
    }
}