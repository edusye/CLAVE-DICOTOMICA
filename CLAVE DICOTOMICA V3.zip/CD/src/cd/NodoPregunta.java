/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cd;

/**
 *
 * @author edusye
 */
public class NodoPregunta extends Nodo {
    private String pregunta;
    private Nodo nodoSi;
    private Nodo nodoNo;

    public NodoPregunta(String id, String pregunta) {
        super(id); // Llama al constructor de Nodo
        this.pregunta = pregunta;
    }

    public String getPregunta() {
        return pregunta;
    }

    public Nodo getNodoSi() {
        return nodoSi;
    }

    public void setNodoSi(Nodo nodoSi) {
        this.nodoSi = nodoSi;
    }

    public Nodo getNodoNo() {
        return nodoNo;
    }

    public void setNodoNo(Nodo nodoNo) {
        this.nodoNo = nodoNo;
    }
}

