/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cd;

import GUI.Ventana1;

/**
 *
 * @author edusye
 */
public class CD {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Ventana1 v1 = new Ventana1();
        v1.setLocationRelativeTo(null);
        v1.setVisible(true);
    }
    
}
